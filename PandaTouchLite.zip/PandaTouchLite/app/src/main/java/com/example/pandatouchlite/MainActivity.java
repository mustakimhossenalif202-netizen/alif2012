package com.example.pandatouchlite;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final String PREFS_NAME = "panda_prefs";
    private static final String KEY_TARGET_PACKAGE = "target_package";

    private EditText targetPackageInput;
    private TextView currentTargetText;
    private Button saveTargetButton;
    private Button enableAccessibilityButton;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        targetPackageInput = findViewById(R.id.targetPackageInput);
        currentTargetText = findViewById(R.id.currentTargetText);
        saveTargetButton = findViewById(R.id.saveTargetButton);
        enableAccessibilityButton = findViewById(R.id.enableAccessibilityButton);

        updateCurrentTargetText();

        saveTargetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String targetPackage = targetPackageInput.getText().toString().trim();
                if (targetPackage.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter the game package name", Toast.LENGTH_SHORT).show();
                    return;
                }
                prefs.edit().putString(KEY_TARGET_PACKAGE, targetPackage).apply();
                updateCurrentTargetText();
                Toast.makeText(MainActivity.this, "Saved target game package", Toast.LENGTH_SHORT).show();
            }
        });

        enableAccessibilityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
    }

    private void updateCurrentTargetText() {
        String target = prefs.getString(KEY_TARGET_PACKAGE, "");
        if (target.isEmpty()) {
            currentTargetText.setText("No game selected yet.");
        } else {
            currentTargetText.setText("Selected game package:\n" + target);
        }
    }
}
