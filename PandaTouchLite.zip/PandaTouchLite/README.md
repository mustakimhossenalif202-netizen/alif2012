PandaTouchLite
=================

Minimal Android app that runs simple macros only when the selected game is foreground. The app stores the game package and the `AccessibilityService` only acts when that package is open.

Setup
-----

1. Import the project into Android Studio.
2. Build and install on your Android device.
3. Open the app.
4. Enter the exact package name of the game you want to use the macro with. For example: `com.pubg.imobile` or `com.tencent.ig`.
5. Tap "Save game package".
6. Tap "Enable Accessibility Service".
7. In Android Settings, open Accessibility and enable the `PandaTouchLite` service.

How it works
--------------

- `MainActivity` saves the chosen package name to shared preferences.
- `MacroService` listens for `TYPE_WINDOW_STATE_CHANGED` events.
- When the current foreground package matches the saved package, the service runs its macro logic.

Testing
-------

1. Install the app on your device.
2. Set a game package in the app.
3. Enable the accessibility service.
4. Open the selected game.
5. The example macro currently performs a single `GLOBAL_ACTION_BACK` when the game becomes foreground.

Important
---------

- Replace the example macro in `MacroService.java` with the real automation you want.
- Do not add intrusive or unsafe actions. Use Android Accessibility responsibly.
